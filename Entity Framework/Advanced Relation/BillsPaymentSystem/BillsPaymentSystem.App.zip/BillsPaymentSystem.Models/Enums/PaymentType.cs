﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.Models.Enums
{
    public enum PaymentType
    {
        BankAccount,
        CreditCard
    }
}
