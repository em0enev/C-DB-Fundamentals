﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.App.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
