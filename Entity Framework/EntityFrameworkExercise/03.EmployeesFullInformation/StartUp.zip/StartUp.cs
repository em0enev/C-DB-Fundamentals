﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace _03.EmployeesFullInformation
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();

            Console.WriteLine(GetEmployeesFullInformation(context));
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees;

            foreach (var emp in employees.OrderBy(e => e.EmployeeId))
            {
                sb.Append($"{emp.FirstName} {emp.LastName} {emp.MiddleName} {emp.JobTitle} {emp.Salary:f2}\n");
            }

            string result = sb.ToString().TrimEnd();

            return result;
        }
    }
}
