﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-VNP1D7N\\SQLEXPRESS;Database=Cinema;Integrated Security=True;";
    }
}
